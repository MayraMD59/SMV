﻿using System.Drawing;

namespace FlatUI
{
	public class FlatColors
	{
		public Color Flat = Helpers.FlatColor;
	}
}
