﻿using System;
using System.Windows.Forms;


namespace VulnerabilidadMaestra
{
	public partial class Screen : Form
		{
		public Screen()
			{
			InitializeComponent();
			if (chkbox_Partials.Checked)
			{
				num_partQ.Enabled = false;
			}
			}


		private void llb_register_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			tab_Control.SelectedTab = tab_SignIn;
		}

		private void flatButton1_Click(object sender, EventArgs e)
		{
			enlistar();
		}

		private void btn_acceptCreateGroup_Click(object sender, EventArgs e)
		{
			enlistar();
		}
		public void enlistar()
		{
			BusinessLogic.global.enlistarBLL();
		}
	}
}
